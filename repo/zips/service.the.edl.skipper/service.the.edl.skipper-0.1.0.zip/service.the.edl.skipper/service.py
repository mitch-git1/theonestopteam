﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import os, json

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))

INTRO_ACTION = 2
OUTRO_ACTION = 4

# --------------------------------------------------
# LOGGING (Kodi log only — correct practice)
# --------------------------------------------------
def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

# --------------------------------------------------
# SETTINGS HELPERS
# --------------------------------------------------
def get_bool(id, default=False):
    try:
        return ADDON.getSettingBool(id)
    except Exception:
        return default


def get_skip_mode(segment):
    """
    Returns: "auto", "popup", or None
    Auto-skip wins if both are enabled.
    """
    if get_bool(f"auto_skip_{segment}", False):
        return "auto"
    if get_bool(f"popup_{segment}", True):
        return "popup"
    return None

# --------------------------------------------------
# CURRENT EPISODE METADATA
# --------------------------------------------------
def get_playback_metadata():
    try:
        return {
            "showtitle": xbmc.getInfoLabel("VideoPlayer.TVShowTitle"),
            "episodetitle": xbmc.getInfoLabel("VideoPlayer.Title"),
            "season": xbmc.getInfoLabel("VideoPlayer.Season"),
            "episode": xbmc.getInfoLabel("VideoPlayer.Episode"),
            "thumb": xbmc.getInfoLabel("ListItem.Thumb"),
        }
    except Exception as e:
        log(f"Metadata error: {e}", xbmc.LOGERROR)
        return {}

# --------------------------------------------------
# TV SHOW ID (LIBRARY LOOKUP)
# --------------------------------------------------
def get_tvshow_id(showtitle):
    try:
        payload = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.GetTVShows",
            "params": {
                "filter": {
                    "field": "title",
                    "operator": "is",
                    "value": showtitle
                },
                "properties": ["title"]
            },
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(payload))
        data = json.loads(response)
        shows = data.get("result", {}).get("tvshows", [])
        return shows[0]["tvshowid"] if shows else None
    except Exception as e:
        log(f"TV show ID lookup failed: {e}", xbmc.LOGERROR)
        return None

# --------------------------------------------------
# NEXT EPISODE METADATA
# --------------------------------------------------
def get_next_episode_metadata_library():
    try:
        showtitle = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        cur_season = int(xbmc.getInfoLabel("VideoPlayer.Season") or 0)
        cur_episode = int(xbmc.getInfoLabel("VideoPlayer.Episode") or 0)

        if not showtitle or cur_season <= 0 or cur_episode <= 0:
            return None

        tvshowid = get_tvshow_id(showtitle)
        if not tvshowid:
            return None

        payload = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.GetEpisodes",
            "params": {
                "tvshowid": tvshowid,
                "properties": ["title", "season", "episode", "art"],
                "sort": {"method": "episode", "order": "ascending"}
            },
            "id": 1
        }

        response = xbmc.executeJSONRPC(json.dumps(payload))
        data = json.loads(response)
        episodes = data.get("result", {}).get("episodes", [])

        for ep in episodes:
            if (ep.get("season", 0) > cur_season or
               (ep.get("season", 0) == cur_season and ep.get("episode", 0) > cur_episode)):
                log(f"Next episode found: {ep.get('title')}")
                return {
                    "showtitle": showtitle,
                    "episodetitle": ep.get("title", ""),
                    "season": str(ep.get("season", "")),
                    "episode": str(ep.get("episode", "")),
                    "thumb": ep.get("art", {}).get("thumb", "")
                }
        return None
    except Exception as e:
        log(f"Next episode lookup failed: {e}", xbmc.LOGERROR)
        return None

# --------------------------------------------------
# EDL PARSER
# --------------------------------------------------
def parse_edl(edl_path):
    entries = []
    try:
        f = xbmcvfs.File(edl_path)
        content = f.read()
        f.close()

        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            parts = line.split()
            if len(parts) < 3:
                continue

            start, end, action = float(parts[0]), float(parts[1]), int(parts[2])

            t = None
            if action == INTRO_ACTION:
                t = "intro"
            elif action == OUTRO_ACTION:
                t = "outro"

            if t:
                entries.append({
                    "type": t,
                    "start": start,
                    "end": end,
                    "id": f"{t}_{start}"
                })
    except Exception as e:
        log(f"EDL parse error: {e}", xbmc.LOGERROR)

    return entries

# --------------------------------------------------
# TITLE CARD DIALOG
# --------------------------------------------------
class TitleCardDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.meta = kwargs.get("meta", {})

    def onInit(self):
        log("TitleCardDialog opened")
        self.setProperty("showtitle", self.meta.get("showtitle", ""))
        self.setProperty("episodetitle", self.meta.get("episodetitle", ""))
        self.setProperty("season", self.meta.get("season", ""))
        self.setProperty("episode", self.meta.get("episode", ""))

# --------------------------------------------------
# SKIP BANNER DIALOG
# --------------------------------------------------
class SkipBannerDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.meta = kwargs.get("meta", {})
        self.segment = kwargs.get("segment", "")
        self.pressed = False
        try:
            self.timeout = int(ADDON.getSetting("popup_timeout"))
        except Exception:
            self.timeout = 5

    def onInit(self):
        self.setProperty("showtitle", self.meta.get("showtitle", ""))
        self.setProperty("episodetitle", self.meta.get("episodetitle", ""))
        self.setProperty("season", self.meta.get("season", ""))
        self.setProperty("episode", self.meta.get("episode", ""))
        self.setProperty("thumbnail", self.meta.get("thumb", ""))
        self.setFocusId(3012)

        for i in range(self.timeout, 0, -1):
            if self.pressed or xbmc.Monitor().abortRequested():
                break
            self.setProperty("countdown", str(i))
            xbmc.sleep(1000)

        self.close()

    def onClick(self, controlId):
        if controlId == 3012:
            self.pressed = True
        self.close()

    def onAction(self, action):
        if action.getId() in (92, 10, 13):
            self.close()

# --------------------------------------------------
# PLAYER MONITOR
# --------------------------------------------------
class PlayerMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.reset()

    def reset(self):
        self.entries = []
        self.handled = set()
        self.notified_steps = set()
        self.current_file = None
        self.meta = {}
        self.next_ep_meta = None
        self.active_outro_dialog = None

    def onPlayBackStarted(self):
        self.reset()
        self.current_file = self.getPlayingFile()
        self.meta = get_playback_metadata()
        log(f"Playback started: {self.meta.get('episodetitle', 'Unknown')}")

        if self.current_file:
            edl = os.path.splitext(xbmcvfs.translatePath(self.current_file))[0] + ".edl"
            if xbmcvfs.exists(edl):
                self.entries = parse_edl(edl)
                log(f"Markers detected: {[e['type'] for e in self.entries]}")

                if any(e['type'] == 'outro' for e in self.entries):
                    self.next_ep_meta = get_next_episode_metadata_library()

    def onPlayBackStopped(self):
        if self.active_outro_dialog:
            self.active_outro_dialog.close()
        self.reset()

# --------------------------------------------------
# SEGMENT HANDLER
# --------------------------------------------------
def handle_segments(player):
    if not get_bool("enabled", True):
        return

    if not player.isPlayingVideo():
        return

    now = player.getTime()

    for e in player.entries:
        if e["id"] in player.handled:
            continue

        mode = get_skip_mode(e["type"])

        # PRE-START PHASE (auto only)
        if mode == "auto" and now < e["start"] and e["start"] > 3:
            time_until_start = e["start"] - now

            if 0 < time_until_start <= 3:
                step = int(time_until_start + 1)
                notify_id = f"{e['id']}_{step}"
                if notify_id not in player.notified_steps:
                    xbmcgui.Dialog().notification(
                        f"Auto Skip {e['type'].capitalize()}",
                        f"Skipping in {step}...",
                        xbmcgui.NOTIFICATION_INFO,
                        1000,
                        False
                    )
                    player.notified_steps.add(notify_id)

            if (
                e["type"] == "outro"
                and 0 < time_until_start <= 3.5
                and not player.active_outro_dialog
            ):
                meta_to_use = player.next_ep_meta or player.meta
                player.active_outro_dialog = TitleCardDialog(
                    "skip_title_outro.xml",
                    ADDON_PATH,
                    "default",
                    "720p",
                    meta=meta_to_use
                )
                player.active_outro_dialog.show()

            continue

        if now < e["start"]:
            continue

        if mode == "auto":
            log(f"Auto-skipping {e['type']}")
            player.seekTime(e["end"])

            if player.active_outro_dialog:
                player.active_outro_dialog.close()
                player.active_outro_dialog = None

            if e["type"] == "intro":
                dlg = TitleCardDialog(
                    "skip_title_intro.xml",
                    ADDON_PATH,
                    "default",
                    "720p",
                    meta=player.meta
                )
                dlg.show()
                xbmc.sleep(3000)
                dlg.close()

        elif mode == "popup":
            meta = player.meta
            xml = "skip_banner.xml"

            if e["type"] == "outro":
                meta = player.next_ep_meta or player.meta
                xml = "skip_banner_outro.xml"

            dlg = SkipBannerDialog(
                xml,
                ADDON_PATH,
                "default",
                "720p",
                meta=meta,
                segment=e["type"]
            )
            dlg.doModal()

            if dlg.pressed:
                player.seekTime(e["end"])

        player.handled.add(e["id"])

# --------------------------------------------------
# MAIN LOOP
# --------------------------------------------------
log("Service Started")
player = PlayerMonitor()
monitor = xbmc.Monitor()

while not monitor.abortRequested():
    if player.isPlayingVideo():
        handle_segments(player)
    xbmc.sleep(250)
