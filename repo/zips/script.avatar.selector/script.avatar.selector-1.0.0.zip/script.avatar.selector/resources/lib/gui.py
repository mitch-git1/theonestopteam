import os
import time
import ctypes
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()

ADDON_PATH = os.path.abspath(
    xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
)

AVATARS_DIR = os.path.abspath(
    os.path.join(ADDON_PATH, "resources", "media", "avatars")
)


class AvatarSelectorWindow(xbmcgui.WindowXML):

    LIST_ID = 50
    PREVIEW_ID = 60
    CANCEL_ID = 70
    OK_ID = 71

    def __init__(self, xml_filename, script_path):
        super().__init__(xml_filename, script_path, "Default", "1080i")
        self.avatar_files = []
        self.last_selected_index = -1

    def onInit(self):
        xbmc.log("Avatar Selector: onInit()", xbmc.LOGINFO)
        
        # Startup notification explaining the behavior
        xbmcgui.Dialog().ok(
            "Avatar Selector",
            "Please note: As soon as you press OK to confirm your chosen image, Kodi will close to apply the changes. Once you reopen Kodi, your new picture will be updated!"
        )
        
        self.populate_list()

    def populate_list(self):
        try:
            avatar_list = self.getControl(self.LIST_ID)
        except Exception as e:
            xbmc.log(f"Avatar Selector: ERROR getting list control: {e}", xbmc.LOGERROR)
            return

        avatar_list.reset()
        self.avatar_files = []

        if not os.path.isdir(AVATARS_DIR):
            xbmc.log(f"Avatar Selector: ERROR - directory missing: {AVATARS_DIR}", xbmc.LOGERROR)
            return

        try:
            files = os.listdir(AVATARS_DIR)
        except Exception as e:
            xbmc.log(f"Avatar Selector: ERROR reading directory: {e}", xbmc.LOGERROR)
            return

        valid_extensions = (".png", ".jpg", ".jpeg", ".webp")

        for filename in sorted(files, key=str.lower):
            if not filename.lower().endswith(valid_extensions):
                continue

            image_path = os.path.join(AVATARS_DIR, filename)
            display_name = os.path.splitext(filename)[0].replace("_", " ").replace("-", " ").title()

            item = xbmcgui.ListItem(label=display_name)
            item.setArt({"thumb": image_path, "icon": image_path})
            item.setProperty("AvatarPath", image_path)
            item.setProperty("AvatarFilename", filename)

            avatar_list.addItem(item)
            self.avatar_files.append(image_path)

        if len(self.avatar_files) > 0:
            try:
                self.setFocusId(self.LIST_ID)
                self.last_selected_index = -1
                self.update_preview()
            except Exception as e:
                xbmc.log(f"Avatar Selector: ERROR focusing list: {e}", xbmc.LOGERROR)

    def update_preview(self):
        try:
            avatar_list = self.getControl(self.LIST_ID)
            selected_index = avatar_list.getSelectedPosition()

            if selected_index < 0 or selected_index >= len(self.avatar_files):
                return
            if selected_index == self.last_selected_index:
                return

            self.last_selected_index = selected_index
            image_path = self.avatar_files[selected_index]

            preview = self.getControl(self.PREVIEW_ID)
            preview.setImage(image_path)
        except Exception as e:
            xbmc.log(f"Avatar Selector: ERROR updating preview: {e}", xbmc.LOGERROR)

    def onClick(self, control_id):
        if control_id == self.LIST_ID:
            self.update_preview()
            return

        if control_id == self.CANCEL_ID:
            xbmc.log("Avatar Selector: User cancelled.", xbmc.LOGINFO)
            self.close()
            return

        if control_id == self.OK_ID:
            xbmc.log("Avatar Selector: OK pressed.", xbmc.LOGINFO)
            self.apply_selected_avatar()
            return

    def apply_selected_avatar(self):
        try:
            avatar_list = self.getControl(self.LIST_ID)
            selected_index = avatar_list.getSelectedPosition()

            if selected_index < 0 or selected_index >= len(self.avatar_files):
                xbmcgui.Dialog().ok("Avatar Selector", "Please select a valid avatar first.")
                return

            source_image_path = self.avatar_files[selected_index]
            original_filename = os.path.basename(source_image_path)
            current_profile = xbmc.getInfoLabel("System.ProfileName") or "Master user"

            # 1. Target active profile folder
            active_profile_dir = xbmcvfs.translatePath("special://profile/")

            # 2. Clean up previous custom avatars in profile folder to prevent clutter
            try:
                if os.path.exists(active_profile_dir):
                    for existing_file in os.listdir(active_profile_dir):
                        if existing_file.startswith("avatar_") and existing_file.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
                            old_file_path = os.path.join(active_profile_dir, existing_file)
                            xbmcvfs.delete(old_file_path)
            except Exception as e:
                xbmc.log(f"Avatar Selector: Could not clean old avatars: {e}", xbmc.LOGWARNING)

            # 3. Create a unique filename so Kodi bypasses texture caching
            timestamp = int(time.time())
            unique_filename = f"avatar_{timestamp}_{original_filename}"
            target_image_path = os.path.join(active_profile_dir, unique_filename)

            # Copy selected image to the profile directory
            if not xbmcvfs.copy(source_image_path, target_image_path):
                xbmc.log("Avatar Selector: Failed to copy image to profile directory.", xbmc.LOGERROR)
                xbmcgui.Dialog().ok("Avatar Selector", "Failed to save the avatar image.")
                return

            # Also update icon.png for fallback compatibility
            icon_path = os.path.join(active_profile_dir, "icon.png")
            if xbmcvfs.exists(icon_path):
                xbmcvfs.delete(icon_path)
            xbmcvfs.copy(source_image_path, icon_path)

            # 4. Update profiles.xml (Dynamically creates <thumbnail> tag if missing for blank profiles)
            profiles_xml_path = os.path.abspath(xbmcvfs.translatePath("special://userdata/profiles.xml"))
            if not os.path.isfile(profiles_xml_path):
                xbmcgui.Dialog().ok("Avatar Selector", "Kodi profiles.xml not found.")
                return

            normalized_image_path = os.path.normpath(target_image_path)

            tree = ET.parse(profiles_xml_path)
            root = tree.getroot()
            profile_found = False

            for profile in root.findall("profile"):
                name_elem = profile.find("name")
                if name_elem is not None and (name_elem.text or "").strip() == current_profile:
                    profile_found = True
                    thumb_elem = profile.find("thumbnail")
                    
                    if thumb_elem is None:
                        thumb_elem = ET.SubElement(profile, "thumbnail")

                    thumb_elem.set("pathversion", "1")
                    thumb_elem.text = normalized_image_path
                    break

            if not profile_found:
                xbmcgui.Dialog().ok("Avatar Selector", f"Could not find profile '{current_profile}' in profiles.xml.")
                return

            if hasattr(ET, "indent"):
                ET.indent(tree, space="    ", level=0)

            tree.write(profiles_xml_path, encoding="utf-8", xml_declaration=True)

            # 5. Close window gracefully first
            self.close()

            # 6. Force an instant hard crash via ctypes null-pointer write to bypass Kodi's memory flush
            try:
                ctypes.memset(0, 1, 1)
            except Exception:
                pass
            
            # Absolute fallback if ctypes is caught: force an exit
            os._exit(1)

        except Exception as e:
            xbmc.log(f"Avatar Selector: Exception in apply_selected_avatar: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Avatar Selector", f"An error occurred:\n{e}")

    def onAction(self, action):
        action_id = action.getId()
        current_id = self.getFocusId()

        if action_id in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            xbmc.log("Avatar Selector: User cancelled.", xbmc.LOGINFO)
            self.close()
            return

        if current_id == self.LIST_ID and action_id in (xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            xbmc.sleep(1)
            self.update_preview()
            return

        if action_id == xbmcgui.ACTION_MOVE_RIGHT:
            if current_id == self.LIST_ID:
                self.setFocusId(self.CANCEL_ID)
                return
            if current_id == self.CANCEL_ID:
                self.setFocusId(self.OK_ID)
                return

        if action_id == xbmcgui.ACTION_MOVE_LEFT:
            if current_id == self.CANCEL_ID:
                self.setFocusId(self.LIST_ID)
                return
            if current_id == self.OK_ID:
                self.setFocusId(self.CANCEL_ID)
                return