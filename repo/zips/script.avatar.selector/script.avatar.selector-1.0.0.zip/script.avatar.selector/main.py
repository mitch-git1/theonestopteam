import sys
import os
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

# Add resources/lib to system path so gui.py can be imported
lib_path = os.path.join(ADDON_PATH, 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.append(lib_path)

from gui import AvatarSelectorWindow

if __name__ == '__main__':
    ui = AvatarSelectorWindow('script-avatar-main.xml', ADDON_PATH)
    ui.doModal()
    del ui