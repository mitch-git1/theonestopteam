﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
from datetime import date

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))

OUTRO_ACTION = 4


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


# --------------------------------------------------
# SNOOZE HELPERS
# --------------------------------------------------
def today():
    return date.today().isoformat()


def snoozed_today():
    return ADDON.getSetting("snooze_until") == today()


def set_snooze_today():
    ADDON.setSetting("snooze_until", today())


def clear_snooze():
    ADDON.setSetting("snooze_until", "")


# --------------------------------------------------
# STILL WATCHING DIALOG
# --------------------------------------------------
class StillWatchingDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.timeout = kwargs.get("timeout", 30)
        self.remaining = self.timeout
        self.result = None
        super().__init__()

    def onInit(self):
        xbmc.executebuiltin("SetFocus(2001)")
        self._update_label()

        while self.remaining > 0 and self.result is None:
            xbmc.sleep(1000)
            self.remaining -= 1
            self._update_label()

        if self.result is None:
            self.result = "stop"
            self.close()

    def _update_label(self):
        try:
            label = "Stopping in %d seconds" % self.remaining
            self.getControl(3001).setLabel(label)
        except Exception as e:
            log(f"Countdown update error: {e}", xbmc.LOGERROR)

    def onAction(self, action):
        if action in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
            xbmcgui.ACTION_STOP
        ):
            self.result = "stop"
            self.close()

    def onClick(self, controlId):
        if controlId == 2001:
            self.result = "continue"
        elif controlId == 2002:
            self.result = "stop"
        elif controlId == 2003:
            self.result = "snooze"
        self.close()


# --------------------------------------------------
# SETTINGS HELPERS
# --------------------------------------------------
def get_bool(id, default=True):
    try:
        return ADDON.getSettingBool(id)
    except Exception:
        return default


def get_int(id, default=0):
    try:
        return int(ADDON.getSetting(id))
    except Exception:
        return default


# --------------------------------------------------
# EDL OUTRO PARSER
# --------------------------------------------------
def get_edl_outro_start(video_path):
    try:
        edl_path = os.path.splitext(video_path)[0] + ".edl"
        edl_path = xbmcvfs.translatePath(edl_path)

        if not xbmcvfs.exists(edl_path):
            return None

        f = xbmcvfs.File(edl_path)
        content = f.read()
        f.close()

        for line in content.splitlines():
            parts = line.strip().split()
            if len(parts) >= 3 and int(parts[2]) == OUTRO_ACTION:
                outro_time = float(parts[0])
                log(f"EDL outro detected at {outro_time}s")
                return outro_time

    except Exception as e:
        log(f"EDL parse error: {e}", xbmc.LOGERROR)

    return None


# --------------------------------------------------
# PLAYER MONITOR
# --------------------------------------------------
class PlaybackGuardian(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.reset()

    def reset(self):
        self.last_file = None
        self.episode_count = 0
        self.trigger_fired = False
        self.cached_outro = None

    def onPlayBackStarted(self):
        if not get_bool("enabled", True):
            return

        current_file = self.getPlayingFile()
        if not current_file:
            return

        if not xbmc.getInfoLabel("VideoPlayer.TVShowTitle"):
            self.last_file = current_file
            return

        if current_file != self.last_file:
            self.episode_count += 1
            self.trigger_fired = False
            self.cached_outro = None
            log(f"Playback started -> episode count = {self.episode_count}")

        self.last_file = current_file

    def onPlayBackStopped(self):
        log("Playback stopped manually")
        clear_snooze()
        self.reset()


# --------------------------------------------------
# MAIN LOOP
# --------------------------------------------------
clear_snooze()
log("Still Watching service started")

player = PlaybackGuardian()
monitor = xbmc.Monitor()

while not monitor.abortRequested():
    if (
        player.isPlayingVideo()
        and get_bool("enabled", True)
        and not player.trigger_fired
        and not snoozed_today()
    ):
        every = get_int("trigger_every", 3)
        notify_before = get_int("notify_seconds", 30)

        if every > 0 and player.episode_count > 0 and player.episode_count % every == 0:
            total = player.getTotalTime()
            current = player.getTime()

            if player.cached_outro is None:
                player.cached_outro = get_edl_outro_start(player.getPlayingFile())

            trigger_ref = player.cached_outro or total
            remaining = trigger_ref - current

            if 0 < remaining <= notify_before:
                log(f"Trigger fired (episode={player.episode_count})")
                player.trigger_fired = True

                xbmc.Player().pause()

                dialog = StillWatchingDialog(
                    "still_watching.xml",
                    ADDON_PATH,
                    "default",
                    timeout=get_int("countdown_seconds", 30)
                )
                dialog.doModal()

                result = dialog.result or "stop"
                del dialog

                if result == "continue":
                    log("User: Continue")
                    xbmc.Player().pause()

                elif result == "snooze":
                    log("User: Snooze")
                    set_snooze_today()
                    xbmc.Player().pause()

                else:
                    log("User: Stop or Timeout")
                    xbmc.Player().stop()
                    player.reset()

    xbmc.sleep(1000)
